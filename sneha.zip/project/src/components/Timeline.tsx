import React from 'react';

const experiences = [
  {
    company: 'TEN HR Consulting',
    role: 'HR Generalist',
    description: 'Team lead of 30, recruitment & training',
    period: 'Present'
  },
  {
    company: 'Walkin Manpower Solution',
    role: 'HR Executive',
    description: 'Hiring & team development',
    period: '2023'
  },
  {
    company: 'Cook N Klean',
    role: 'HR Intern',
    description: 'Resume screening, interviews, onboarding',
    period: '2023'
  },
  {
    company: 'Edubrainz Company',
    role: 'HR Executive',
    description: 'Recruitment & performance management',
    period: '2022'
  },
  {
    company: 'Lernx India',
    role: 'HR Intern',
    description: 'Sales recruitment specialist',
    period: '2022'
  },
  {
    company: 'Basti ki Paathshala',
    role: 'HR & Fundraising Intern',
    description: 'Recruitment assistance',
    period: '2021'
  }
];

function Timeline() {
  return (
    <div className="relative">
      <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gray-200"></div>
      <div className="space-y-12">
        {experiences.map((exp, index) => (
          <div key={index} className="relative">
            <div className="flex items-center">
              <div className="flex-1 text-right pr-8">
                <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                  <h3 className="text-xl font-semibold text-gray-900">{exp.company}</h3>
                  <h4 className="text-teal-600 font-medium">{exp.role}</h4>
                  <p className="text-gray-600 mt-2">{exp.description}</p>
                </div>
              </div>
              <div className="absolute left-1/2 transform -translate-x-1/2">
                <div className="w-4 h-4 rounded-full bg-teal-600 border-4 border-white"></div>
              </div>
              <div className="flex-1 pl-8">
                <div className="text-lg font-medium text-gray-500">{exp.period}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Timeline;